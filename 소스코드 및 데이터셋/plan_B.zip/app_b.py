import pickle
import streamlit as st
import pandas as pd

df1 = pickle.load(open('df1.pickle', 'rb'))
cosine_sim = pickle.load(open('cosine_sim.pickle', 'rb'))

st.set_page_config(layout='wide')
st.header('장애인 운동 도우미(plan_B)')

def create_input(x):
    return ''.join(x['AGRDE_FLAG_NM'])+' '+''.join(x['SEXDSTN_FLAG_CD'])+' '+''.join(x['TROBL_TY_NM'])+' '+''.join(x['TROBL_DETAIL_NM'])+' '+''.join(x['TROBL_GRAD_NM'])

# 질문지 세부사항을 입력 받으면 코사인 유사도를 통해서 0.1과 0.75 사이에 
# 해당되는 유사도를 가진 값 중 가장 빈도가 높은 5개의 목록을 반환하는 함수

def get_recommendations_1(input, cosine_sim = cosine_sim):
    # 답변 값에 따라서 전체 데이터 기준 해당되는 인덱스 값 할당 받기
    # 이때 답변이 같은 경우 첫번째 인댁스를 할당 받기
    indices = pd.Series(df1.index, index=df1['input'])
    idx = indices[input][0]
    
    #코사인 유사도 메트릭스(cosine_sim)에서 idx에 해당되는 데이터를 (idx, 유사도)형태로 얻기
    sim_scores = list(enumerate(cosine_sim[idx]))
    
    #코사인 유사도를 기준으로 내림차순 정렬
    sim_scores = sorted(sim_scores, key = lambda x: x[1], reverse = True)
    
    #코사인 유사도의 범위 중 0.75이상 1.0미만인 범위 추출
    valid_range = 0
    filter_1 = []
    for i in range(len(sim_scores)):
        valid_range = sim_scores[i][1]
        if 0.75 <= valid_range <= 1:
            filter_1.append(valid_range)
    
    #추출한 범위 중 중복 값 제거        
    filter_2 = []
    for i in filter_1:
        if i not in filter_2:
            filter_2.append(i)
    
    #범위 내에 있는 인덱스 정보 추출
    Prescription = []
    for i in sim_scores:
        for j in range(len(filter_2)):
            if filter_2[j] in i:
                Prescription.append(i)
        
    #추천 목록의 인덱스 정보 추출
    Prescription_indices = [i[0] for i in Prescription]
    
    #기존 데이터 셋에서 인덱스 정보에 맞는 운동 결과 추출
    Prescription_list = df1['RECOMEND_MVM_NM'].iloc[Prescription_indices]
    
    
    Prescription_list = Prescription_list.value_counts(sort = True).nlargest(5).to_frame()
    
    #이중 가장 빈도 수가 높은 5개의 운동 값 추출
    return pd.DataFrame(Prescription_list.index , columns = ['상위 5개 추천운동'])

# recommend_exercise= st.text_input('연령대 성별 장애종류 세부장애요소 장애등급 순으로 입력해주세요.', 'ex) 10대 F 척수장애 사지마비 완전 마비')

age_list = df1['AGRDE_FLAG_NM'].sort_values().unique()
sex_list = df1['SEXDSTN_FLAG_CD'].sort_values().unique()
trobl_type_list = df1['TROBL_TY_NM'].sort_values().unique()
trobl_detail_list = df1['TROBL_DETAIL_NM'].sort_values().unique()
trobl_grade_list = df1['TROBL_GRAD_NM'].sort_values().unique()

age = st.selectbox('연령대를 선택하세요',age_list)
sex = st.selectbox('성별을 선택하세요',sex_list)
trobl_type = st.selectbox('장애 유형을 선택하세요',trobl_type_list)
trobl_detail = st.selectbox('손상 정도를 선택하세요',trobl_detail_list)
trobl_grade = st.selectbox('장애 등급을 선택하세요',trobl_grade_list)


if st.button('선택'):
    with st.spinner('Please wait...'):
        # titles = get_recommendations_1(recommend_exercise)
        df1['input'] = df1.apply(create_input, axis = 1) 
        titles = get_recommendations_1(df1['input'])
        titles
