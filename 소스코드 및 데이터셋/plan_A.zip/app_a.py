import pickle
import streamlit as st

def search_class(sido, gungu, jang):
    df1 = cla.loc[cla['CTPRVN_NM'].str.contains(sido) & cla['SIGNGU_NM'].str.contains(gungu) & cla['TROBL_TY_NM'].str.contains(jang)].copy()
    return df1
    
def search_group(sido, gungu, jang):
    df2 = group.loc[group['CTPRVN_NM'].str.contains(sido) & group['SIGNGU_NM'].str.contains(gungu) & group['TROBL_TY_NM'].str.contains(jang)].copy()
    return df2

def search(sido, gungu):
    df3 = centers.loc[centers['ALSFC_CTPRVN_NM'].str.contains(sido) & centers['ALSFC_SIGNGU_NM'].str.contains(gungu)].copy()
    return df3.drop_duplicates()

centers = pickle.load(open('centers.pickle', 'rb'))
cla = pickle.load(open('cla.pickle', 'rb'))
group = pickle.load(open('group.pickle', 'rb'))

st.set_page_config(layout='wide')
st.header('장애인 운동 도우미(plan_A)')

city_list = group['CTPRVN_NM'].sort_values().unique()
# si_gun_list = cla['SIGNGU_NM'].sort_values().unique()
disabled_list = cla['TROBL_TY_NM'].sort_values().unique()
local_city = st.selectbox('도시를 선택하세요', city_list)
# local_si_gun= st.selectbox('행정구역(시/구/군)을 선택하세요', si_gun_list)
local_si_gun= st.text_input('행정구역(시/구/군)을 선택하세요', 'ex) 가평군 or 성북구')
disabled = st.selectbox('장애 유형을 선택해주세요', disabled_list)

if st.button('선택'):
    with st.spinner('Please wait...'):

        st.subheader('운동 수업 목록')
        classes = search_class(local_city, local_si_gun, disabled)
        classes.rename(columns = {'ITEM_NM':'운동 종류','SUBITEM_NM':'기타 운동 종류','CLSSRM_NM':'수업 이름','OPER_TIME_CN': '수업 시간'},inplace=True)
        classes.loc[:,['운동 종류', '기타 운동 종류', '수업 이름', '수업 시간']]

        st.subheader('운동 동호회 목록')
        clubs = search_group(local_city, local_si_gun, disabled)
        clubs.rename(columns = {'ITEM_NM':'운동 종류','CLUB_NM':'동호회 이름','OPER_TIME_CN': '모임 시간','CLUB_INTRCN_CN' : '동호회 소개'},inplace=True)
        clubs.loc[:,['운동 종류','동호회 이름', '모임 시간', '동호회 소개']]

        st.subheader('체육 편의 시설 목록')
        gyms = search(local_city, local_si_gun)
        gyms.rename(columns = {'ALSFC_NM':'체육 시설 이름','ALSFC_ADDR':'체육 시설 주소','ALSFC_DETAIL_ADDR': '체육 시설 세부 주소','ALSFC_MAIN_ITEM_NM' : '운동 종목'},inplace=True)
        gyms.loc[:,['체육 시설 이름', '체육 시설 주소','체육 시설 세부 주소', '운동 종목']]

